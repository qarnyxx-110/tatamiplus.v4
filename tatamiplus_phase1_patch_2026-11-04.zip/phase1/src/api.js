/** API boundary for Phase 1. Mock mode is explicit and never represents real OTP/payment. */
const MOCK = import.meta.env.VITE_API_MODE !== 'live';
const BASE = (import.meta.env.VITE_API_BASE || '').replace(/\/$/, '');
async function request(path, options={}) {
  if (MOCK) return mock(path, options);
  const response = await fetch(`${BASE}${path}`, {credentials:'include', headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.message || 'درخواست انجام نشد.');
  return data;
}
async function mock(path, options) {
  await new Promise(r=>setTimeout(r,220));
  const body = options.body ? JSON.parse(options.body) : {};
  if(path==='/auth/request-otp/') return {ok:true, mock:true, resend_in:120, masked_phone:body.phone};
  if(path==='/auth/verify-otp/') return {ok:true, mock:true, is_new_user:!localStorage.getItem('tp_user'), user:JSON.parse(localStorage.getItem('tp_user')||'null')};
  if(path==='/auth/register/') {const user={...body, phone:sessionStorage.getItem('tp_phone'), role:sessionStorage.getItem('tp_role')};localStorage.setItem('tp_user',JSON.stringify(user));return {ok:true,user,mock:true};}
  if(path==='/checkout/pay/') return {ok:true,mock:true,order_id:`TP-${Date.now().toString().slice(-7)}`,status:'pending',redirect_url:null};
  if(path.startsWith('/checkout/status/')) return {ok:true,mock:true,status:'pending'};
  return {ok:true,mock:true};
}
export const api = {mock:MOCK, requestOtp:phone=>request('/auth/request-otp/',{method:'POST',body:JSON.stringify({phone})}), verifyOtp:(phone,code)=>request('/auth/verify-otp/',{method:'POST',body:JSON.stringify({phone,code})}), register:data=>request('/auth/register/',{method:'POST',body:JSON.stringify(data)}), pay:data=>request('/checkout/pay/',{method:'POST',body:JSON.stringify(data)}), getStatus:id=>request(`/checkout/status/${encodeURIComponent(id)}/`)};
