# فهرست فایل‌های تغییرکرده — فاز یک

- `.htaccess` — مسیردهی مسیرهای فاز یک به اپ مستقل؛ مسیر ریشه/Preview حفظ شده است.
- `phase1/package.json` — وابستگی‌ها و فرمان‌های React/Vite/Tailwind v4.
- `phase1/vite.config.js` — تنظیم build برای انتشار در `/phase1/`.
- `phase1/index.html` — پوسته RTL برنامه.
- `phase1/src/main.jsx` — صفحات و جریان‌های فاز یک.
- `phase1/src/style.css` — طراحی واکنش‌گرا، RTL و موبایل‌محور.
- `phase1/src/api.js` — مرز API و Mock صریح.
- `phase1/src/products.json` — کپی ۵۹ محصول از داده فعلی.
- `phase1/README.md` — راهنمای build، انتشار و اتصال API.
- `PHASE1_IMPLEMENTATION_REPORT.md` — گزارش محدوده و محدودیت‌ها.
- `TEST_REPORT_PHASE1.md` — نتایج تست واقعی.
- `CONTINUE-PROMPT.md` — دستور ادامه کار.
- `CHECKPOINT-MANIFEST.json` — وضعیت checkpoint.
